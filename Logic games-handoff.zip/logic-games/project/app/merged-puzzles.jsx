/* global React */
const { useState, useEffect, useRef } = React;

function CheckM({ cls }) {
  return (
    <svg className={cls} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round">
      <path d="M5 12.5l4.2 4.2L19 7" />
    </svg>
  );
}
function ArrowGlyphM({ deg = 0 }) {
  return (
    <svg viewBox="0 0 48 48" style={{ transform: `rotate(${deg}deg)` }} fill="none">
      <path className="s-primary" d="M24 9 L24 34" strokeWidth="3.6" strokeLinecap="round" />
      <path className="s-accent" d="M15 25 L24 34 L33 25" strokeWidth="3.6" strokeLinecap="round" strokeLinejoin="round" />
      <circle className="f-good" cx="24" cy="11" r="3.6" />
    </svg>
  );
}
function PennantM({ deg = 0, mirror = false }) {
  return (
    <svg viewBox="0 0 48 48" fill="none" style={{ transform: `rotate(${deg}deg) scaleX(${mirror ? -1 : 1})` }}>
      <path className="s-primary" d="M16 8 L16 40" strokeWidth="3.6" strokeLinecap="round" />
      <path className="f-accent" d="M16 9 L36 15 L16 23 Z" />
    </svg>
  );
}

function PatternPuzzleM({ puzzle, solved, onSolve, onMiss }) {
  const [pick, setPick] = useState(null);
  const { seq, options, answer } = puzzle.data;
  function choose(i) {
    if (solved) return;
    setPick(i);
    if (i === answer) setTimeout(onSolve, 200);
    else { onMiss && onMiss(); setTimeout(() => setPick(null), 480); }
  }
  return (
    <>
      <div className="reel-stage">
        <div className="seq">
          {seq.map((d, i) => (
            <React.Fragment key={i}>
              <div className="seq-tile"><ArrowGlyphM deg={d} /></div>
              <span className="seq-arrow">›</span>
            </React.Fragment>
          ))}
          <div className="seq-tile q"><span>?</span></div>
        </div>
        <p className="hint-line">{puzzle.hint}</p>
      </div>
      <div className="reel-input">
        {solved ? null : (
          <div className="opt-grid">
            {options.map((d, i) => {
              let c = "opt";
              if (pick === i) c += i === answer ? " correct" : " wrong";
              return <button key={i} className={c} onClick={() => choose(i)}><div style={{ width: 42, height: 42 }}><ArrowGlyphM deg={d} /></div></button>;
            })}
          </div>
        )}
      </div>
    </>
  );
}

function NumberPuzzleM({ puzzle, solved, onSolve, onMiss }) {
  const { grid, qIndex, answer } = puzzle.data;
  const [val, setVal] = useState("");
  const [wrong, setWrong] = useState(false);
  function press(k) {
    if (solved) return;
    setWrong(false);
    if (k === "del") { setVal(v => v.slice(0, -1)); return; }
    if (k === "ok") {
      if (parseInt(val, 10) === answer) onSolve();
      else { setWrong(true); onMiss && onMiss(); setTimeout(() => setWrong(false), 500); }
      return;
    }
    setVal(v => (v.length >= 3 ? v : v + k));
  }
  return (
    <>
      <div className="reel-stage">
        <div className="ngrid">
          {grid.map((n, i) => (
            <div key={i} className={"ncell" + (i === qIndex ? " q" : "")}>
              {i === qIndex ? (solved ? answer : (val || "?")) : n}
            </div>
          ))}
        </div>
        <p className="hint-line">{puzzle.hint}</p>
      </div>
      <div className="reel-input">
        {solved ? null : (
          <>
            <div className={"answer-display" + (val ? "" : " empty") + (wrong ? " err" : "")}>{val || "??"}</div>
            <div className="keypad">
              {["1","2","3","4","5","6","7","8","9"].map(k => (<button key={k} className="key" onClick={() => press(k)}>{k}</button>))}
              <button className="key util" onClick={() => press("del")}>DEL</button>
              <button className="key" onClick={() => press("0")}>0</button>
              <button className="key go" onClick={() => press("ok")}>GO</button>
            </div>
          </>
        )}
      </div>
    </>
  );
}

function WordPuzzleM({ puzzle, solved, onSolve, onMiss }) {
  const { letters, accept } = puzzle.data;
  const [placed, setPlaced] = useState([]);
  const [wrong, setWrong] = useState(false);
  const usedFrom = placed.map(p => p.from);
  function place(ch, idx) {
    if (solved || usedFrom.includes(idx) || placed.length >= letters.length) return;
    const next = [...placed, { ch, from: idx }];
    setPlaced(next);
    if (next.length === letters.length) {
      const w = next.map(p => p.ch).join("");
      if (accept.includes(w)) setTimeout(onSolve, 180);
      else { setWrong(true); onMiss && onMiss(); setTimeout(() => { setWrong(false); setPlaced([]); }, 600); }
    }
  }
  return (
    <>
      <div className="reel-stage">
        <div className={"word-slots" + (wrong ? " err" : "")}>
          {letters.map((_, i) => (
            <div key={i} className={"slot" + (placed[i] ? " filled" : "")}>{solved ? accept[0][i] : (placed[i] ? placed[i].ch : "")}</div>
          ))}
        </div>
        <p className="hint-line">{puzzle.hint}</p>
      </div>
      <div className="reel-input">
        {solved ? null : (
          <>
            <div className="letter-tray">
              {letters.map((ch, i) => (<button key={i} className={"tile" + (usedFrom.includes(i) ? " used" : "")} onClick={() => place(ch, i)}>{ch}</button>))}
            </div>
            <button className="btn btn-ghost" onClick={() => !solved && setPlaced([])} disabled={!placed.length}>↺ Reset</button>
          </>
        )}
      </div>
    </>
  );
}

function SpatialPuzzleM({ puzzle, solved, onSolve, onMiss }) {
  const { options, answer } = puzzle.data;
  const [pick, setPick] = useState(null);
  function choose(i) {
    if (solved) return;
    setPick(i);
    if (i === answer) setTimeout(onSolve, 200);
    else { onMiss && onMiss(); setTimeout(() => setPick(null), 480); }
  }
  return (
    <>
      <div className="reel-stage">
        <div className="spatial-hero"><div className="shape-card"><PennantM deg={0} /></div></div>
        <p className="hint-line">{puzzle.hint}</p>
      </div>
      <div className="reel-input">
        {solved ? null : (
          <div className="opt-grid">
            {options.map((o, i) => {
              let c = "opt shape";
              if (pick === i) c += i === answer ? " correct" : " wrong";
              return <button key={i} className={c} onClick={() => choose(i)}><div style={{ width: 52, height: 52 }}><PennantM deg={o.deg} mirror={o.mirror} /></div></button>;
            })}
          </div>
        )}
      </div>
    </>
  );
}

function MemoryPuzzleM({ puzzle, solved, onSolve, onMiss }) {
  const { sequence } = puzzle.data;
  const [phase, setPhase] = useState("idle");
  const [lit, setLit] = useState(-1);
  const [pos, setPos] = useState(0);
  const [wrongPad, setWrongPad] = useState(-1);
  const timers = useRef([]);
  function clearTimers() { timers.current.forEach(clearTimeout); timers.current = []; }
  useEffect(() => clearTimers, []);
  function show() {
    clearTimers(); setPhase("show"); setPos(0);
    sequence.forEach((p, i) => {
      timers.current.push(setTimeout(() => setLit(p), 620 * i + 300));
      timers.current.push(setTimeout(() => setLit(-1), 620 * i + 680));
    });
    timers.current.push(setTimeout(() => setPhase("input"), 620 * sequence.length + 400));
  }
  function tap(p) {
    if (phase !== "input" || solved) return;
    setLit(p); setTimeout(() => setLit(-1), 160);
    if (p === sequence[pos]) {
      const np = pos + 1; setPos(np);
      if (np === sequence.length) setTimeout(onSolve, 220);
    } else { setWrongPad(p); setPhase("idle"); setPos(0); onMiss && onMiss(); setTimeout(() => setWrongPad(-1), 500); }
  }
  const status = solved ? "" :
    phase === "idle" ? "Memorize the sequence, then echo it back." :
    phase === "show" ? "LOCK IT IN…" :
    `YOUR TURN · ${pos}/${sequence.length}`;
  return (
    <>
      <div className="reel-stage">
        <div className="pad-grid">
          {[0,1,2,3].map(p => (<button key={p} className={"pad p" + p + (lit === p ? " lit" : "") + (wrongPad === p ? " bad" : "")} onClick={() => tap(p)} />))}
        </div>
        <p className="mem-status">{status}</p>
      </div>
      <div className="reel-input">
        {solved ? null : (
          phase === "input"
            ? <p className="hint-line">Tap the pads in the exact order they fired.</p>
            : <button className="btn btn-primary" onClick={show} disabled={phase === "show"}>{phase === "show" ? "WATCHING…" : "▶ START SEQUENCE"}</button>
        )}
      </div>
    </>
  );
}

const PUZZLES_M = [
  { id: "pat1", skill: "LOGIC", skillFull: "Pattern Logic", diff: "EASY", lang: false,
    prompt: "Crack the sequence — what comes next?", hint: "Each one rotates a quarter-turn clockwise.",
    type: "pattern", xp: 100, data: { seq: [0, 90, 180], options: [270, 90, 0, 45], answer: 0 } },
  { id: "num1", skill: "MATH", skillFull: "Speed Math", diff: "MEDIUM", lang: false,
    prompt: "One cell is missing. What belongs there?", hint: "Scan each row for the rule.",
    type: "number", xp: 150, data: { grid: [2, 3, 6, 4, 2, 8, 3, "?", 15], qIndex: 7, answer: 5 } },
  { id: "word1", skill: "WORDS", skillFull: "Word Scramble", diff: "EASY", lang: true,
    prompt: "Unscramble the four letters into a word.", hint: "A word for a settled, unhurried mind.",
    type: "word", xp: 100, data: { letters: ["M", "L", "A", "C"], accept: ["CALM", "CLAM"] } },
  { id: "spa1", skill: "SPATIAL", skillFull: "Spatial Twist", diff: "HARD", lang: false,
    prompt: "Three are rotations. One is a fake — spot it.", hint: "One flag is mirrored, not turned.",
    type: "spatial", xp: 220, data: { options: [ { deg: 90, mirror: false }, { deg: 0, mirror: true }, { deg: 180, mirror: false }, { deg: 270, mirror: false } ], answer: 1 } },
  { id: "mem1", skill: "MEMORY", skillFull: "Memory Rush", diff: "HARD", lang: false,
    prompt: "Watch the pads fire, then echo the order.", hint: "Four in a row. Don’t blink.",
    type: "memory", xp: 220, data: { sequence: [0, 3, 1, 2] } },
];

function PuzzleBodyM(props) {
  switch (props.puzzle.type) {
    case "pattern": return <PatternPuzzleM {...props} />;
    case "number":  return <NumberPuzzleM {...props} />;
    case "word":    return <WordPuzzleM {...props} />;
    case "spatial": return <SpatialPuzzleM {...props} />;
    case "memory":  return <MemoryPuzzleM {...props} />;
    default: return null;
  }
}

Object.assign(window, { PUZZLES_M, PuzzleBodyM, CheckM, ArrowGlyphM, PennantM });
