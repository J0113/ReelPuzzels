/* global React, ReactDOM, PUZZLES_M, PuzzleBodyM, CheckM, ArrowGlyphM, PennantM */
const { useState, useEffect, useRef, useCallback } = React;

const DECAY = 22;            // seconds until speed bonus reaches 0
const BONUS_FACTOR = 0.6;    // max speed bonus = xp * factor

const IBolt = () => (<svg viewBox="0 0 24 24" fill="currentColor"><path d="M13 2L4 14h6l-1 8 9-12h-6l1-8z"/></svg>);
const IFlame = () => (<svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 2c1 3-1 4-2 6-1 1.6-1 3 0 4 .6-1 1.4-1.6 2-3 1.5 2 3 3.3 3 6a5 5 0 11-10 0c0-3 2-5 3-7 1-2 3-3 4-6z"/></svg>);
const ITrophy = () => (<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.9" strokeLinecap="round" strokeLinejoin="round"><path d="M6 4h12v4a6 6 0 01-12 0V4zM6 6H3v1a3 3 0 003 3M18 6h3v1a3 3 0 01-3 3M9 20h6M12 14v6"/></svg>);
const IGrid = () => (<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.9" strokeLinecap="round" strokeLinejoin="round"><rect x="4" y="4" width="7" height="7" rx="1.6"/><rect x="13" y="4" width="7" height="7" rx="1.6"/><rect x="4" y="13" width="7" height="7" rx="1.6"/><rect x="13" y="13" width="7" height="7" rx="1.6"/></svg>);
const IClose = () => (<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M6 6l12 12M18 6L6 18"/></svg>);
const IChevUp = () => (<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round"><path d="M6 15l6-6 6 6"/></svg>);
const IPlay = () => (<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round"><path d="M8 5l11 7-11 7V5z"/></svg>);
const IBrain = () => (<svg viewBox="0 0 32 32" fill="currentColor"><path d="M11 5a4 4 0 00-4 4 4 4 0 00-2 7 4 4 0 003 6 4 4 0 008 0V7a3 3 0 00-5-2zM21 5a3 3 0 015 2v15a4 4 0 01-8 0V7a3 3 0 013-2z"/></svg>);
const IDot = () => (<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round"><path d="M5 12.5l4 4L19 7"/></svg>);

const fmt = (s) => `${Math.floor(s / 60)}:${String(s % 60).padStart(2, "0")}`;

/* puzzle thumbnail icon for the menu */
function PuzzleIco({ type }) {
  if (type === "pattern") return <div style={{ width: 26, height: 26 }}><ArrowGlyphM deg={90} /></div>;
  if (type === "spatial") return <div style={{ width: 26, height: 26 }}><PennantM deg={30} /></div>;
  if (type === "number") return <span style={{ fontWeight: 800, fontSize: 18, color: "var(--a-primary)" }}>5</span>;
  if (type === "word") return <span style={{ fontWeight: 800, fontSize: 15, color: "var(--a-accent)", letterSpacing: "0.02em" }}>Aa</span>;
  if (type === "memory") return (<div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 3 }}>
    <span style={{ width: 9, height: 9, borderRadius: 3, background: "var(--pad0)" }} /><span style={{ width: 9, height: 9, borderRadius: 3, background: "var(--pad1)" }} />
    <span style={{ width: 9, height: 9, borderRadius: 3, background: "var(--pad2)" }} /><span style={{ width: 9, height: 9, borderRadius: 3, background: "var(--pad3)" }} /></div>);
  return null;
}

/* ============================================================ FEED ============================================================ */
function Feed({ index, setIndex, solved, setSolved, stats, setStats, onOpenMenu, onOpenStats }) {
  const [burst, setBurst] = useState(null);
  const [elapsed, setElapsed] = useState(0);
  const trackRef = useRef(null);
  const drag = useRef({ active: false, startY: 0, dy: 0 });
  const max = PUZZLES_M.length - 1;
  const cur = PUZZLES_M[index];
  const isSolved = !!solved[cur.id];

  const go = useCallback((next) => setIndex(Math.max(0, Math.min(max, next))), [max, setIndex]);

  const maxBonus = Math.round(cur.xp * BONUS_FACTOR);
  const bonus = isSolved ? 0 : Math.max(0, Math.round(maxBonus * (1 - elapsed / DECAY)));
  const bonusPct = maxBonus ? (bonus / maxBonus) * 100 : 0;
  const mState = bonusPct < 25 ? "crit" : bonusPct < 55 ? "warn" : "";

  /* reset stopwatch when landing on an unsolved puzzle */
  useEffect(() => { setElapsed(0); }, [index]);
  /* count UP */
  useEffect(() => {
    if (isSolved) return;
    const t = setInterval(() => setElapsed(e => e + 1), 1000);
    return () => clearInterval(t);
  }, [isSolved, index]);

  function handleSolve() {
    if (solved[cur.id]) return;
    const earnedBonus = Math.max(0, Math.round(maxBonus * (1 - elapsed / DECAY)));
    const newStreak = stats.streak + 1;
    const combo = newStreak >= 2 ? newStreak : 0;
    const comboBonus = combo ? combo * 15 : 0;
    const gained = cur.xp + earnedBonus + comboBonus;
    setSolved({ ...solved, [cur.id]: true });
    setBurst({ id: cur.id, combo, gained, bonus: earnedBonus, time: elapsed });
    setStats({
      ...stats,
      xp: stats.xp + gained,
      streak: newStreak,
      bestStreak: Math.max(stats.bestStreak, newStreak),
      solvedCount: stats.solvedCount + 1,
      timeSum: stats.timeSum + elapsed,
    });
  }

  function onDown(e) { drag.current = { active: true, startY: (e.touches ? e.touches[0].clientY : e.clientY), dy: 0 }; }
  function onMove(e) {
    if (!drag.current.active) return;
    const y = e.touches ? e.touches[0].clientY : e.clientY;
    drag.current.dy = y - drag.current.startY;
    const base = -index * 100;
    const pct = (drag.current.dy / window.innerHeight) * 100 * 0.9;
    if (trackRef.current) { trackRef.current.style.transition = "none"; trackRef.current.style.transform = `translateY(calc(${base}% + ${pct}px))`; }
  }
  function onUp() {
    if (!drag.current.active) return;
    const dy = drag.current.dy; drag.current.active = false;
    if (trackRef.current) { trackRef.current.style.transition = ""; trackRef.current.style.transform = ""; }
    if (dy < -70) go(index + 1); else if (dy > 70) go(index - 1);
  }
  useEffect(() => {
    let lock = false;
    function onWheel(e) { if (lock || Math.abs(e.deltaY) < 14) return; lock = true; go(index + (e.deltaY > 0 ? 1 : -1)); setTimeout(() => { lock = false; }, 600); }
    const el = trackRef.current?.parentElement;
    el?.addEventListener("wheel", onWheel, { passive: true });
    return () => el?.removeEventListener("wheel", onWheel);
  }, [index, go]);

  return (
    <div className="screen">
      <div className="field-bg" />
      <div className="hud">
        <div className="brand"><span className="brand-mark"><IBrain /></span><span className="brand-name">Reel<b>Puzzels</b></span></div>
        <div className="hud-chip streak"><IFlame />{stats.streak}</div>
        <div className="hud-chip xp"><IBolt />{stats.xp}</div>
        <button className="icon-btn" onClick={onOpenMenu} aria-label="Puzzle menu"><IGrid /></button>
        <button className="icon-btn" onClick={onOpenStats} aria-label="Stats"><ITrophy /></button>
      </div>

      {!isSolved && (
        <div className="meter-wrap">
          <div className="meter-meta">
            <span className="meter-label">SPEED BONUS</span>
            <span className="bonus-num">+{bonus}</span>
            <span className="elapsed">{fmt(elapsed)}</span>
          </div>
          <div className="meter-track"><div className={"meter-fill " + mState} style={{ width: bonusPct + "%" }} /></div>
        </div>
      )}

      <div className="reel-dots">{PUZZLES_M.map((p, i) => <i key={p.id} className={i === index ? "on" : (solved[p.id] ? "done" : "")} />)}</div>

      <div className="feed" onTouchStart={onDown} onTouchMove={onMove} onTouchEnd={onUp}
        onMouseDown={onDown} onMouseMove={onMove} onMouseUp={onUp} onMouseLeave={onUp}>
        <div ref={trackRef} className="reel-track" style={{ transform: `translateY(${-index * 100}%)` }}>
          {PUZZLES_M.map((p, i) => {
            const pSolved = !!solved[p.id];
            const showBurst = burst && burst.id === p.id;
            const bd = showBurst ? burst : null;
            return (
              <div className="reel" key={p.id} data-screen-label={`Reel ${i + 1} · ${p.skillFull} (${p.diff})`}>
                <div className="reel-head">
                  <div className="badge-row">
                    <span className={"skill-pill" + (p.lang ? " lang" : "")}><span className="dot" />{p.skill}</span>
                    <span className={"diff-tag " + p.diff}>{p.diff}</span>
                    <span className="diff-tag xp">+{p.xp} XP</span>
                  </div>
                  <h1 className="reel-prompt">{p.prompt}</h1>
                </div>

                <PuzzleBodyM puzzle={p} solved={pSolved} onSolve={handleSolve} onMiss={() => {}} />

                {showBurst && (
                  <div className="solve-burst">
                    <div className="solve-wash" />
                    <div className="solve-check"><CheckM /></div>
                    {bd.combo ? <div className="combo-pop">{bd.combo}× COMBO!</div> : null}
                    <span className="speck s0" style={{ left: "44%", top: "48%" }} />
                    <span className="speck s1" style={{ left: "52%", top: "50%" }} />
                    <span className="speck s2" style={{ left: "48%", top: "46%" }} />
                  </div>
                )}

                {pSolved && (
                  <div className="solved-tray">
                    <div className="score-row">
                      <span className="score-chip xp"><IBolt /> +{bd ? bd.gained : p.xp}</span>
                      {bd && <span className="score-chip time">⏱ {fmt(bd.time)}{bd.bonus > 0 ? ` · +${bd.bonus} fast` : " · base"}</span>}
                    </div>
                    {i < max ? (
                      <button className="swipe-cue" onClick={() => go(index + 1)}><IChevUp /><span>SWIPE UP · NEXT PUZZLE</span></button>
                    ) : (
                      <div className="swipe-cue last-note"><span>RUN COMPLETE · CHECK YOUR STATS</span></div>
                    )}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

/* ============================================================ THEME SEG ============================================================ */
function ThemeSeg({ theme, setTheme }) {
  return (
    <div className="seg" role="group" aria-label="Color theme">
      <button className={theme === "calm" ? "on" : ""} onClick={() => setTheme("calm")}><span className="sw" style={{ background: "#6F9E45" }} />Calm</button>
      <button className={theme === "neon" ? "on" : ""} onClick={() => setTheme("neon")}><span className="sw" style={{ background: "#1FE6FF" }} />Neon</button>
    </div>
  );
}

/* ============================================================ ONBOARDING ============================================================ */
function Onboarding({ onBegin, onBrowse, theme, setTheme }) {
  return (
    <div className="onb screen screen-enter">
      <div className="field-bg" />
      <div className="onb-top"><ThemeSeg theme={theme} setTheme={setTheme} /></div>
      <div className="onb-art">
        <div className="onb-ring r2" /><div className="onb-ring r1" />
        <div className="onb-orb"><IBrain /></div>
      </div>
      <div className="onb-copy">
        <div className="onb-kicker">ReelPuzzels · Brain Reel</div>
        <h1 className="onb-title">Think it through.<br/><em>One reel at a time.</em></h1>
        <p className="onb-text">Swap the endless feed for one puzzle at a time. Solve faster for more points, build combos, and watch your skills climb — calm or charged, your call.</p>
        <div className="onb-points">
          <div className="onb-point" style={{ color: "var(--a-primary)" }}><IDot /> Beat your time</div>
          <div className="onb-point" style={{ color: "var(--a-warm)" }}><IDot /> Build combos</div>
          <div className="onb-point" style={{ color: "var(--a-good)" }}><IDot /> Climb levels</div>
        </div>
        <div className="onb-actions">
          <button className="btn btn-primary" onClick={onBegin}>⚡ Start the reel</button>
          <button className="btn btn-ghost" onClick={onBrowse}>Browse puzzles</button>
        </div>
      </div>
    </div>
  );
}

/* ============================================================ MENU ============================================================ */
function Menu({ solved, theme, setTheme, onPlay, onResume, onOpenStats, onClose }) {
  return (
    <div className="menu screen screen-enter">
      <div className="field-bg" />
      <div className="menu-head">
        <div>
          <div className="menu-kicker">Brain Reel</div>
          <h1 className="menu-title">Pick a puzzle</h1>
        </div>
        <button className="icon-btn" onClick={onClose} aria-label="Close"><IClose /></button>
      </div>

      <div className="theme-block">
        <div>
          <div className="tb-label">Color theme</div>
          <div className="tb-sub">Calm earth tones or charged neon</div>
        </div>
        <ThemeSeg theme={theme} setTheme={setTheme} />
      </div>

      <div className="menu-section">Jump back in</div>
      <div className="glist">
        <button className="gcard" onClick={onResume}>
          <div className="gcard-ico"><IPlay /></div>
          <div className="gcard-main"><div className="gcard-name">Resume the reel</div>
            <div className="gcard-meta"><span className="diff-tag xp">Continue where you left off</span></div></div>
          <div className="gcard-go"><IChevUp style={{ transform: "rotate(90deg)" }} /></div>
        </button>
        <button className="gcard" onClick={onOpenStats}>
          <div className="gcard-ico"><ITrophy /></div>
          <div className="gcard-main"><div className="gcard-name">Your scorecard</div>
            <div className="gcard-meta"><span className="diff-tag xp">XP, streak & skills</span></div></div>
          <div className="gcard-go"><IChevUp style={{ transform: "rotate(90deg)" }} /></div>
        </button>
      </div>

      <div className="menu-section">All puzzles</div>
      <div className="glist">
        {PUZZLES_M.map((p, i) => (
          <button key={p.id} className={"gcard" + (solved[p.id] ? " done-card" : "")} onClick={() => onPlay(i)}>
            <div className="gcard-ico"><PuzzleIco type={p.type} /></div>
            <div className="gcard-main">
              <div className="gcard-name">{p.skillFull}</div>
              <div className="gcard-meta">
                <span className={"diff-tag " + p.diff}>{p.diff}</span>
                <span className="diff-tag xp">+{p.xp} XP</span>
              </div>
            </div>
            <div className="gcard-go">{solved[p.id] ? <IDot /> : <IPlay />}</div>
          </button>
        ))}
      </div>
    </div>
  );
}

/* ============================================================ STATS ============================================================ */
const SKILLS_M = [
  { name: "Spatial Twist", val: 82, delta: "+14 ▲", pink: false },
  { name: "Pattern Logic", val: 74, delta: "+8 ▲", pink: false },
  { name: "Memory Rush", val: 66, delta: "+5 ▲", pink: false },
  { name: "Word Scramble", val: 71, delta: "+11 ▲", pink: true },
  { name: "Speed Math", val: 60, delta: "+4 ▲", pink: false },
];

function Stats({ stats, onClose }) {
  const [fill, setFill] = useState(false);
  useEffect(() => { const t = setTimeout(() => setFill(true), 140); return () => clearTimeout(t); }, []);
  const level = Math.floor(stats.xp / 500) + 1;
  const intoLevel = stats.xp % 500;
  const ranks = ["Rookie", "Sharpshooter", "Tactician", "Mastermind", "Brain Beast"];
  const rank = ranks[Math.min(level - 1, ranks.length - 1)];
  const avg = stats.solvedCount ? Math.round(stats.timeSum / stats.solvedCount) : 0;

  return (
    <div className="insights screen screen-enter">
      <div className="field-bg" />
      <div className="hud" style={{ position: "static", paddingTop: 0, marginBottom: 4 }}>
        <div style={{ marginRight: "auto" }} />
        <button className="icon-btn" onClick={onClose} aria-label="Close"><IClose /></button>
      </div>
      <div className="ins-head">
        <div className="ins-kicker">This week’s run</div>
        <h1 className="ins-title">Your<br/>scorecard</h1>
      </div>

      <div className="card level-card">
        <div className="level-row">
          <div className="level-badge"><b>{level}</b></div>
          <div style={{ flex: 1 }}><div className="level-label">Current rank</div><div className="level-name">{rank}</div></div>
        </div>
        <div className="level-xp">
          <div className="xp-track"><div className="xp-fill" style={{ width: fill ? (intoLevel / 500 * 100) + "%" : 0 }} /></div>
          <div className="xp-meta"><span>{stats.xp} XP total</span><span>{500 - intoLevel} to level {level + 1}</span></div>
        </div>
      </div>

      <div className="stat-grid" style={{ marginBottom: 12 }}>
        <div className="stat"><div className="stat-num orange">{stats.bestStreak}</div><div className="stat-label">Best streak</div></div>
        <div className="stat"><div className="stat-num cyan">{stats.solvedCount}</div><div className="stat-label">Solved</div></div>
        <div className="stat"><div className="stat-num pink">{avg}s</div><div className="stat-label">Avg solve</div></div>
      </div>

      <div className="card">
        <div className="card-label">Skill power</div>
        <div className="skills">
          {SKILLS_M.map(s => (
            <div className="skill-row" key={s.name}>
              <div className="sk-top"><span className="sk-name">{s.name}</span><span className="sk-delta">{s.delta}</span></div>
              <div className="sk-track"><div className={"sk-fill" + (s.pink ? " pink" : "")} style={{ width: fill ? s.val + "%" : 0 }} /></div>
            </div>
          ))}
        </div>
      </div>

      <div className="card">
        <div className="card-label">Achievements</div>
        <div className="ach-row">
          <div className="ach"><div className="ach-ico">🔥</div><div className="ach-name">Hot Streak</div></div>
          <div className="ach"><div className="ach-ico">⚡</div><div className="ach-name">Speed Demon</div></div>
          <div className="ach locked"><div className="ach-ico">🧠</div><div className="ach-name">Mastermind</div></div>
          <div className="ach locked"><div className="ach-ico">💎</div><div className="ach-name">Flawless</div></div>
        </div>
      </div>
    </div>
  );
}

/* ============================================================ APP ============================================================ */
function load(key, fallback) { try { const v = JSON.parse(localStorage.getItem(key)); return v == null ? fallback : v; } catch { return fallback; } }

function App() {
  const [screen, setScreen] = useState(() => localStorage.getItem("rp2_screen") || "onboarding");
  const [theme, setTheme] = useState(() => localStorage.getItem("rp2_theme") || "neon");
  const [index, setIndex] = useState(() => load("rp2_index", 0));
  const [solved, setSolved] = useState(() => load("rp2_solved", {}));
  const [stats, setStats] = useState(() => load("rp2_stats", { xp: 640, streak: 0, bestStreak: 7, solvedCount: 18, timeSum: 216 }));

  useEffect(() => { localStorage.setItem("rp2_screen", screen); }, [screen]);
  useEffect(() => { localStorage.setItem("rp2_theme", theme); }, [theme]);
  useEffect(() => { localStorage.setItem("rp2_index", JSON.stringify(index)); }, [index]);
  useEffect(() => { localStorage.setItem("rp2_solved", JSON.stringify(solved)); }, [solved]);
  useEffect(() => { localStorage.setItem("rp2_stats", JSON.stringify(stats)); }, [stats]);

  return (
    <div className="stage" data-theme={theme}>
      {screen === "onboarding" && <Onboarding theme={theme} setTheme={setTheme} onBegin={() => { setIndex(0); setScreen("feed"); }} onBrowse={() => setScreen("menu")} />}
      {screen === "feed" && <Feed index={index} setIndex={setIndex} solved={solved} setSolved={setSolved} stats={stats} setStats={setStats} onOpenMenu={() => setScreen("menu")} onOpenStats={() => setScreen("stats")} />}
      {screen === "menu" && <Menu solved={solved} theme={theme} setTheme={setTheme}
        onPlay={(i) => { setIndex(i); setScreen("feed"); }} onResume={() => setScreen("feed")}
        onOpenStats={() => setScreen("stats")} onClose={() => setScreen("feed")} />}
      {screen === "stats" && <Stats stats={stats} onClose={() => setScreen("feed")} />}
    </div>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
